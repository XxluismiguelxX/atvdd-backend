const openapi = {
 openapi: '3.0.3',
 info: { title: 'Livraria API', version: '1.0.0', description: 'Documentação interativa da API de livros e autores.' },
 servers: [{ url: 'http://localhost:3000' }],
 components: {
  securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
  schemas: {
   Erro: { type: 'object', properties: { erro: { type: 'string', example: 'Descrição do erro.' } } },
   CadastroUsuario: { type: 'object', required: ['nome','email','senha'], properties: { nome: {type:'string',example:'Ana Souza'}, email:{type:'string',format:'email',example:'ana@email.com'}, senha:{type:'string',format:'password',example:'Senha123!'}, role:{type:'string',enum:['USER','ADMIN'],example:'USER'} } },
   Login: { type:'object', required:['email','senha'], properties:{ email:{type:'string',format:'email',example:'leitor@gmail.com'}, senha:{type:'string',format:'password',example:'Senha123!'} } },
   AutorEntrada: {type:'object',required:['nome'],properties:{nome:{type:'string',example:'Carolina Maria de Jesus'},nacionalidade:{type:'string',example:'Brasileira'}}},
   LivroEntrada: {type:'object',required:['titulo','autor_id'],properties:{titulo:{type:'string',example:'Quarto de Despejo'},ano:{type:'integer',example:1960},autor_id:{type:'integer',example:1}}},
   ComentarioEntrada: {type:'object',required:['texto'],properties:{texto:{type:'string',minLength:1,example:'Uma leitura marcante.'}}}
  }
 },
 paths: {
  '/api/v1/livros': {
   get:{summary:'Listar livros',description:'Retorna todos os livros cadastrados. Acesso público.',responses:{'200':{description:'Lista de livros retornada.'},'500':{description:'Erro interno.'}}},
   post:{summary:'Cadastrar livro',description:'Cadastra livro; exclusivo ADMIN.',security:[{bearerAuth:[]}],requestBody:{required:true,content:{'application/json':{schema:{$ref:'#/components/schemas/LivroEntrada'}}}},responses:{'201':{description:'Livro cadastrado.'},'400':{description:'Dados ausentes.'},'401':{description:'Token ausente ou inválido.'},'403':{description:'Perfil sem permissão.'},'404':{description:'Autor inexistente.'}}}
  },
  '/api/v1/livros/{id}': {get:{summary:'Buscar livro por ID',description:'Consulta pública de um livro.',parameters:[{name:'id',in:'path',required:true,schema:{type:'integer',example:1}}],responses:{'200':{description:'Livro encontrado.'},'404':{description:'Livro não localizado.'}}}},
  '/api/v1/livros/{id}/comentarios': {post:{summary:'Comentar um livro',description:'Requer usuário autenticado USER ou ADMIN.',security:[{bearerAuth:[]}],parameters:[{name:'id',in:'path',required:true,schema:{type:'integer',example:1}}],requestBody:{required:true,content:{'application/json':{schema:{$ref:'#/components/schemas/ComentarioEntrada'}}}},responses:{'201':{description:'Comentário criado.'},'400':{description:'Texto ausente ou vazio.'},'401':{description:'Token ausente ou inválido.'},'404':{description:'Livro não localizado.'}}}},
  '/api/v1/auth/register': {post:{summary:'Registrar usuário',description:'Cria conta com perfil USER por padrão; e-mail duplicado retorna 409.',requestBody:{required:true,content:{'application/json':{schema:{$ref:'#/components/schemas/CadastroUsuario'}}}},responses:{'201':{description:'Usuário criado.'},'400':{description:'Campos obrigatórios ausentes.'},'422':{description:'Dados inválidos.'},'409':{description:'E-mail já cadastrado.'}}}},
  '/api/v1/auth/login': {post:{summary:'Login',description:'Retorna usuário e token para usar no botão Authorize.',requestBody:{required:true,content:{'application/json':{schema:{$ref:'#/components/schemas/Login'}}}},responses:{'200':{description:'Login realizado.'},'400':{description:'E-mail ou senha ausentes.'},'422':{description:'Dados inválidos.'},'401':{description:'Credenciais inválidas.'}}}},
  '/api/v1/autores': {post:{summary:'Cadastrar autor',description:'Exclusivo ADMIN.',security:[{bearerAuth:[]}],requestBody:{required:true,content:{'application/json':{schema:{$ref:'#/components/schemas/AutorEntrada'}}}},responses:{'201':{description:'Autor criado.'},'400':{description:'Nome ausente.'},'401':{description:'Token ausente ou inválido.'},'403':{description:'Perfil sem permissão.'}}}}
 }
};
module.exports = openapi;
