# Livraria API — OpenAPI 3.0 e Swagger UI

API em Node.js/Express com documentação interativa.

## Executar localmente

1. Instale Node.js (versão LTS).
2. No terminal, entre na pasta `livraria-api-node-main/livraria-api-node-main`.
3. Execute:

```bash
npm install
npm start
```

4. Abra:
   - Swagger UI: http://localhost:3000/docs
   - Especificação OpenAPI JSON: http://localhost:3000/docs/api.json
   - Verificação simples: http://localhost:3000/

## Como testar as rotas protegidas

1. No Swagger, abra `POST /api/v1/auth/login`, clique em **Try it out** e envie `email` e `senha`.
2. Copie o valor `token` da resposta.
3. Clique em **Authorize** e cole o token (sem escrever `Bearer `; a interface acrescenta o prefixo).
4. Execute as rotas protegidas.

## Rotas documentadas

- `GET /api/v1/livros`
- `GET /api/v1/livros/{id}`
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `POST /api/v1/livros/{id}/comentarios`
- `POST /api/v1/autores`
- `POST /api/v1/livros`

## Importante sobre a implementação recebida

A documentação descreve o contrato pedido na atividade, mas o código original da aula ainda usa autenticação simulada: o login gera um token de exemplo e o middleware não valida assinatura/expiração JWT nem diferencia realmente USER de ADMIN. O cadastro também não aplica BCrypt de verdade. Para uma entrega de segurança funcional, substitua os trechos marcados como simulação por `bcrypt` e `jsonwebtoken`, e valide o perfil no middleware. A interface Authorize funciona para enviar o Bearer nas requisições, mas não transforma o token simulado em JWT real.
