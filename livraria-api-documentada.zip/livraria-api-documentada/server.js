const express = require('express');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');
const openapi = require('./openapi');

const authRoutes = require('./routes/authRoutes');
const livroRoutes = require('./routes/livroRoutes');
const autorRoutes = require('./routes/autorRoutes');
const errorHandler = require('./middlewares/errorMiddleware');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Documentação OpenAPI 3.0
app.get('/docs/api.json', (req, res) => res.json(openapi));
app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapi, {
  explorer: true,
  customSiteTitle: 'Livraria API - Documentação',
  swaggerOptions: { persistAuthorization: true }
}));

app.get('/', (req, res) => res.json({
  mensagem: 'Livraria API',
  documentacao: '/docs',
  especificacao: '/docs/api.json'
}));

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/livros', livroRoutes);
app.use('/api/v1/autores', autorRoutes);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Livraria API rodando em http://localhost:${PORT}`);
  console.log(`Swagger UI em http://localhost:${PORT}/docs`);
});
